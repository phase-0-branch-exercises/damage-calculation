/*
========================
LETTER GROUPING
========================
[INSTRUCTIONS]
Letter grouping adalah sebuah fungsi yang menerima parameter berupa string huruf
dan akan mengembalikan nilai berupa array dengan masing-masing kelompok angka.

RULES:
1. Tidak perlu menggunakan pseudocode
2. Tidak boleh menggunakan built in function .sort()
3. Group selalu dimulai dari huruf A dan diakhiri dengan huruf terakhir sesuai
input yang diberikan

EXAMPLE
INPUT: "AAABCF"
OUTPUT:
  [
    ["A", "A", "A"],
    ["B"],
    ["C"],
    [],
    [],
    ["F"]
  ]

NOTES:
1. Pada contoh, karena huruf "D" dan "E" tidak ada dalam input,
maka hanya berisi array kosong
2. Total array atau kelompok angka sesuai angka terakhir pada input.
3. WAJIB menggunakan PSEUDOCODE
*/

function letterGrouping(letters) {
  // code below here
}

console.log(letterGrouping('ABDCCCE')); // [ [ 'A' ], [ 'B' ], [ 'C', 'C', 'C' ], [ 'D' ], [ 'E' ] ]
console.log(letterGrouping('ABC')); // [ [ 'A' ], [ 'B' ], [ 'C' ] ]
console.log(letterGrouping('F')); // [[], [], [], [], [], ['F]]
console.log(letterGrouping('EAB')); // [['A'], ['B'], [], [], ['E']]
console.log(letterGrouping('BBABB')); // [[ 'A' ], [ 'B', 'B', 'B', 'B' ]]